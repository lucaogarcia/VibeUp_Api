const tunelamento_URL = "https://gnat-huge-gibbon.ngrok-free.app";
const localhost_URL = "http://localhost:8080";

const API_URL = tunelamento_URL || localhost_URL;

export default API_URL;
