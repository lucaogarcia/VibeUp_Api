const postURL = "http://localhost:8080/login";
const signupURL = "http://localhost:8080/signup";

const submitButton = document.querySelector("#login-form__submit");
const revealButton = document.querySelector(".button-form__reveal-password");
const passwordInput = document.querySelector("#input-form__password");
const eye = document.querySelector(".icon-tabler-eye");
const eyeClosed = document.querySelector(".icon-tabler-eye-closed");

//
//
//

let userValue = document.querySelector("#input-form__email").value;
let passwordValue = document.querySelector("#input-form__password").value;
let userInput = document.querySelector("#input-form__email");

let loginErrorMessageValidation = document.querySelector(
	".span-form__login-warning-message"
);

let passwordErrorMessageValidation = document.querySelector(
	".span-form__error-password-message"
);

revealButton.addEventListener("click", (e) => {
	e.preventDefault();
	console.log("clicked");

	if (passwordInput.type === "password") {
		passwordInput.type = "text";
		eye.classList.add("hidden");
		eyeClosed.classList.remove("hidden");
	} else {
		passwordInput.type = "password";
		eye.classList.remove("hidden");
		eyeClosed.classList.add("hidden");
	}
});

async function sendUser(url = "http://localhost:8080/login", data = {}) {
	const response = await fetch(url, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify(data),
	});
	return response.json();
}

submitButton.addEventListener("click", (e) => {
	const login = {
		user: userValue,
		password: passwordValue,
	};

	if (validateFields()) {
		sendUser("http://localhost:8080/login", login)
			.then((response) => {
				localStorage.setItem("toke", response.token);
			})
			.then(
				setTimeout(() => {
					window.location.href =
						"http://127.0.0.1:5500/html/signup.html";
				}, 800)
			)
			.catch((error) => console.error("Error:", error));
	} else {
		console.log("Ooops, it's not working");
	}
	e.preventDefault();
});

const char = [];
const hashToken = [];
const hashTokenLength = 64;

for (let i = 0; i < 10; i++) {
	char.push(i);
}

for (let i = 97; i < 97 + 26; i++) {
	char.push(String.fromCharCode(i));
}

for (let i = 0; i < hashTokenLength; i++) {
	hashToken.push(char[Math.floor(Math.random() * char.length)]);

	const rand1 = Math.floor(Math.random() * 3);
	const rand2 = Math.floor(Math.random() * 3);

	if (rand1 === rand2) {
		if (typeof hashToken[i] === "string") {
			hashToken[i] = hashToken[i].toUpperCase();
		}
	}
}

token = hashToken.join("");
console.log(hashToken.join(""));
const key = localStorage.setItem("token", token);

let userInputFlag = false;

function validateFields() {
	let isValid = false;

	const FieldInput = {
		email: {
			valueMissing: false,
			typeMismatch: false,
		},
		password: {
			valueMissing: false,
		},
	};

	const setError = (inputElement, errorElement, errorMessage, field) => {
		errorElement.textContent = errorMessage;
		errorElement.style.visibility = "initial";
		inputElement.classList.add("inputErrorMessage");
		field.valueMissing = true;
	};

	const clearError = (inputElement, errorElement) => {
		errorElement.style.visibility = "hidden";
		inputElement.classList.remove("inputErrorMessage");
	};

	if (userInput.validity.valueMissing) {
		setError(
			userInput,
			loginErrorMessageValidation,
			"Preencha o campo",
			FieldInput.email
		);
	} else if (userInput.validity.typeMismatch) {
		setError(
			userInput,
			loginErrorMessageValidation,
			"E-mail inválido",
			FieldInput.email
		);
	} else {
		clearError(userInput, loginErrorMessageValidation);
	}

	if (passwordInput.validity.valueMissing) {
		setError(
			passwordInput,
			passwordErrorMessageValidation,
			"Preencha o campo",
			FieldInput.password
		);
	} else {
		clearError(passwordInput, passwordErrorMessageValidation);
	}

	console.log(
		Object.values(FieldInput.email)
			.concat(Object.values(FieldInput.password))
			.every((field) => field === false)
	);

	if (
		Object.values(FieldInput.email)
			.concat(Object.values(FieldInput.password))
			.every((field) => field === false)
	) {
		isValid = true;
	}

	return isValid;
}

const logo = document.querySelector("header");

logo.addEventListener("click", () => {
	window.location.href = "http://127.0.0.1:5500/html/start.html";
});
